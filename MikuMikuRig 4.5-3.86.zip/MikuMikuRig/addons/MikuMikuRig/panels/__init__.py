import os
import bpy
from bpy.props import *

from MikuMikuRig.addons.MikuMikuRig.config import __addon_name__

# 哇哦~文件缓存系统得了mvp！
file_cache = {
    ".json": {"mtime": 0, "files": [], "files_ic": []},
    ".py": {"mtime": 0, "files": [], "files_ic": []}
}

# 获取预设目录
def get_presets_directory():
    new_path = os.path.dirname(os.path.dirname(__file__))
    return os.path.join(new_path, 'operators', 'presets')

TARGET_FOLDER = get_presets_directory()  # 预设目录

# 获取预设文件列表
def get_file_list(extension):
    global file_cache

    try:
        # 获取当前扩展名的缓存
        cache = file_cache[extension]
        current_mtime = os.path.getmtime(TARGET_FOLDER)

        # 检查目录修改时间和缓存有效性
        if current_mtime == cache["mtime"] and cache["files"]:
            return cache["files"]

        valid_files = []
        valid_files_ic = []

        # 遍历目录并过滤文件
        for f in os.listdir(TARGET_FOLDER):
            file_path = os.path.join(TARGET_FOLDER, f)
            if os.path.isfile(file_path) and f.endswith(extension):
                # 提取基础文件名和生成描述
                base_name = os.path.splitext(f)[0]
                valid_files.append(base_name)
                valid_files_ic.append(f"选择文件：{base_name}")

        # 更新当前扩展名的缓存
        file_cache[extension] = {
            "mtime": current_mtime,
            "files": sorted(valid_files, key=str.lower),
            "files_ic": sorted(valid_files_ic, key=str.lower)
        }

        return file_cache[extension]["files"]

    except Exception as e:
        print(f"预设加载错误: {str(e)}")
        return []


def make_presets_enum(extension):
    def update_file_list(self, context):
        files = get_file_list(extension)  # 传入扩展名参数
        cache = file_cache[extension]

        items = []
        # 安全遍历：确保两个列表长度一致
        for idx in range(min(len(files), len(cache["files_ic"]))):
            items.append((
                files[idx],
                files[idx],
                cache["files_ic"][idx]
            ))

        extension_jn = ['.json']

        if extension in extension_jn:

            items.append((
                "mmr_preset_editor",
                "MMR预设编辑器",
                "导入MMR预设编辑器中的预设"
            ))

        # 处理空列表情况
        return items or [("NONE", "无可用文件", "空预设")]

    return update_file_list

class MMR_property(bpy.types.PropertyGroup):
    # 控制器预设（.json）
    presets: EnumProperty(
        name="Controller Presets",
        description="选择控制器预设配置",
        items=make_presets_enum('.json'),
    )

    # 重定向预设（.py）
    py_presets: EnumProperty(
        name="Retarget Presets",
        description="选择骨骼重定向预设配置",
        items=make_presets_enum('.py'),
    )

    # MMR rigid body是否已构建
    mmr_root_is_built: BoolProperty(
        name="MMR Root Is Built",
        default=False,
    )

    # 禁用手掌修正
    Disable_hand_fix: BoolProperty(
        name="Disable hand fix",
        default=False,
        description="禁用手掌修正"
    )
    # 禁用脚趾位置约束
    Disable_toe_position_constraint: BoolProperty(
        name="Disable toe position constraint",
        default=False,
        description="禁用脚趾(toe)骨骼位置约束"
    )
    # 接着生成控制器
    Generate_controllers: BoolProperty(
        name="Generate controllers",
        default=False,
        description="生成控制器"
    )

    # 启用手指IK
    Enable_finger_IK: BoolProperty(
        name="Enable Finger IK",
        default=True,
        description="启用手指IK"
    )

    # 权重骨骼父级修正
    Weight_bone_parent_fix: BoolProperty(
        name="Weight bone parent fix",
        default=False,
        description="权重骨骼父级修正，可以将真正有权重的骨骼的父级设置为无权重骨骼，以带动权重骨骼"
    )

    # mmd_Armature
    mmd_Armature: PointerProperty(
        type=bpy.types.Object,
        name="mmd_Armature",
    )

    filepath: StringProperty(
        name="",
        subtype='FILE_PATH'
    )

    select_deselect_all_items: BoolProperty(
        name="Select/Deselect All Items",
        default=False
    )

    MMR_Arm: BoolProperty(
        name='MMR Arm',
        default=False,
    )

    number: IntProperty(
        name="Int Config",
        default=2,
    )

    Towards_the_dialog_box: BoolProperty(
        name="Sets the default orientation",
        default=False,
        description="如果模型的正面朝向-Y，就选择-Y"
    )

    boolean: BoolProperty(
        name="Boolean Config",
        default=False,
    )

    Manually_adjust_VMD_movements: BoolProperty(
        name="Manually adjust VMD movements",
        default=False,
        description="手动调整VMD动作"
    )

    Manually_adjust_FBX_movements: BoolProperty(
        name="Manually adjust FBX movements",
        default=False,
        description="手动调整FBX动作"
    )

    # 创建布尔属性作为极向目标开关
    Polar_target: BoolProperty(
        name="Polar target",
        default=False
    )

    # 额外选项
    extras_enabled: BoolProperty(
        name="Extras Enabled",
        default=False
    )

    Shoulder_linkage: BoolProperty(
        name="Shoulder linkage",
        default=False
    )

    json_filepath: StringProperty(
        name="",
        subtype='FILE_PATH',
        description="导入json字典预设"
    )

    Import_presets: BoolProperty(
        name="Import presets",
        default=False,
        description="导入json字典预设"
    )
    Bend_the_bones: BoolProperty(
        name="Bend the bones",
        default=False,
        description='弯曲手臂骨骼'
    )
    Only_meta_bones_are_generated: BoolProperty(
        name="Only meta bones are generated",
        default=False,
        description="仅生成元骨骼"
    )
    # 吸取物体数据
    Import_object_data: PointerProperty(
        type=bpy.types.Object,
        name="Import object data",
    )
    # key物体
    key_obj: PointerProperty(
        type=bpy.types.Object,
        name="Key object",
    )
    # key idx
    key_idx: IntProperty(
        name="Key index",
        default=0,
    )
    make_presets: BoolProperty(
        default=True,
    )
    number: IntProperty(
        default=0,
    )
    json_txt: StringProperty(
        name="",
        subtype='FILE_NAME',
    )
    designated: BoolProperty(
        default=True,
    )

    designated: BoolProperty(
        default=True,
    )
    Copy_the_file: BoolProperty(
        default=True,
    )
    Preset_editor: BoolProperty(
        default=False
    )
    Reference_bones: BoolProperty(
        default=False
    )
    # 是否显示关节
    joint_show: BoolProperty(
        default=False,
    )
    f_pin: BoolProperty(
        default=True,
    )
    Finger_options: BoolProperty(
        default=False,
    )
    Thumb_twist_aligns_with_the_world_Z_axis: BoolProperty(
        default=False,
    )
    # 隐藏骨架
    Hide_mmd_skeleton: BoolProperty(
        default=False,
    )
    # 弯曲腿部骨骼
    Bend_the_leg_bones: BoolProperty(
        default=False,
        description="弯曲腿部骨骼"
    )
    # 弯曲角度（腿部）
    Bend_angle_leg: FloatProperty(
        default=2.5,
    )
    # 弯曲角度（手臂）
    Bend_angle_arm: FloatProperty(
        default=6,
    )
    # 使用ITASC解算器
    Use_ITASC_solver: BoolProperty(
        default=False,
        description="IK解算器使用ITASC算法,最精确,但要弯曲四肢骨骼"
    )
    # ORG模式
    ORG_mode: BoolProperty(
        default=False,
        description="使用 MMR 1.20版的约束算法"
    )
    # 设置捩骨预设
    Wrist_twist_preset: BoolProperty(
        name="Wrist twist preset",
        default=False,
        description="选择捩骨预设",
    )
    # 左大臂扭转名称
    Left_upper_arm_twist: StringProperty(
        default="腕捩.L",
        description="左大臂扭转名称"
    )
    # 右大臂扭转名称
    Right_upper_arm_twist: StringProperty(
        default="腕捩.R",
        description="右大臂扭转名称"
    )
    # 左小臂扭转名称
    Left_lower_arm_twist: StringProperty(
        default="手捩.L",
        description="左小臂扭转名称"
    )
    # 右小臂扭转名称
    Right_lower_arm_twist: StringProperty(
        default="手捩.R",
        description="右小臂扭转名称"
    )
    # 面板预设
    panel_preset: BoolProperty(
        name="Panel preset",
        default=False,
        description="自定义面板预设"
    )

    # 面板预设 “bone”
    panel_preset_bone: StringProperty(
        default="頭",
        description="自定义面板预设 “bone”"
    )
    # 面板预设 “A”
    panel_preset_A: StringProperty(
        default="あ",
        description="自定义面板预设 “A”"
    )
    # 面板预设 “I”
    panel_preset_I: StringProperty(
        default="い",
        description="自定义面板预设 “I”"
    )
    # 面板预设 “U”
    panel_preset_U: StringProperty(
        default="う",
        description="自定义面板预设 “U”"
    )
    # 面板预设 “E”
    panel_preset_E: StringProperty(
        default="え",
        description="自定义面板预设 “E”"
    )
    # 面板预设 “O”
    panel_preset_O: StringProperty(
        default="お",
        description="自定义面板预设 “O”"
    )
    # 软度
    Softness: FloatProperty(
        default=0.4,
        min=0,
        max=1,
    )
    # 是否开启物理
    physics_bool: BoolProperty(
        default=False,
    )
    # 转换完成后要不要隐藏MMD刚体部分
    Hide_mmd_rigidbody: BoolProperty(
        default=True,
    )
    # 批量调整形态
    Batch_adjust_shape_key: FloatProperty(
        default=0.0,
        step=0.1,
        description="批量调整形态"
    )
    # 是否注册处理器
    register_handler: BoolProperty(
        default=True,
    )
    # 是否自动插入关键帧
    use_keyframe_insert_auto: BoolProperty(
        default=False,
        description="是否自动插入关键帧"
    )
    # 存储上一次的值用于比较
    last_batch_adjust_value: FloatProperty(
        default=0.0,
    )
    # 选中的key里有关键帧的才会插入关键帧
    insert_keyframe: BoolProperty(
        default=False,
        description="选中的形态键里有关键帧的才会插入关键帧"
    )
    # 是否直接操作形态键
    direct_operation_shape_key: BoolProperty(
        default=True,
        description="是否直接操作形态键"
    )
    # 是否开启物理
    physics_bool: BoolProperty(
        default=False,
    )
    # 是否开启IK导入
    IK_import_bool: BoolProperty(
        default=False,
        description="是否开启VMD动作IK导入"
    )
    frame_step: IntProperty(
        default=2,
        description="帧步长，值越高，烘培越快，精度越低"
    )

    Physics_frame_step: IntProperty(
        default=2,
        description="帧步长，值越高，烘培越快，精度越低"
    )

    # mmd_tool额外选项
    mmd_tool_extras: BoolProperty(
        default=False,
        description="mmd_tool额外选项"
    )
    # 是否显示刚体
    show_rigid_bodies: BoolProperty(
        default=False,
    )
    # 是否显示原文键名
    show_original_key_name: BoolProperty(
        default=False,
        description="是否显示原文键名"
    )
    # 偏好设置
    preference: BoolProperty(
        default=False,
        description="偏好设置"
    )
    # 约束名称
    constraintswitchtool_name_enum: EnumProperty(
        name="Mode",
        description="约束名称",
        items={
            ("0", "自定义约束名称", "自定义约束名称"),
            ("1", "mmr_physics", "mmr_physics"),
            ("2", "mmd_tools_rigid_track", "mmd_tools_rigid_track"),
            ("3", "MMR-阻尼追踪", "MMR-阻尼追踪"),
        },
        default="0"
    )
    constraintswitchtool_name: StringProperty(
        default="",
        description="自定义约束名称"
    )

class MMR_Weight_bone_parent_fix(bpy.types.PropertyGroup):
    key: StringProperty(name="Key", default="")
    value: StringProperty(name="Value", default="")

class MMR_Automatic_IK_bone_chain(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(
        name="",
        default="",
        description="自动IK的骨骼"
    )
    # 分割线
    separator: bpy.props.BoolProperty(
        default=False,
        description="分割线"
    )

class MMR_bone_property(bpy.types.PropertyGroup):

    Set_constraints: bpy.props.BoolVectorProperty(
        name='Set constraints',
        size=3,
        default=(True,) * 3,
        description="Set bone constraints"
    )

    # 阻尼跟踪开关
    Damping_Tracking_bool: bpy.props.BoolProperty(
        default=False,
        description="阻尼跟踪开关"
    )
    # 存储阻尼跟踪影响
    Damping_Tracking_influence: bpy.props.FloatProperty(
        default=0.0,
        min=0.0,
        max=1.0,
        description="阻尼跟踪影响"
    )
    # 是否插入阻尼跟踪影响帧
    Insert_dt_keyframe: bpy.props.BoolProperty(
        default=False,
        description="是否插入阻尼跟踪影响帧"
    )
    # 约束开关
    Constraint_bool: bpy.props.BoolProperty(
        default=False,
        description="约束开关"
    )
    # 存储约束影响
    Constraint_influence: bpy.props.FloatProperty(
        default=0.0,
        min=0.0,
        max=1.0,
        description="约束影响"
    )
    # 是否插入约束影响帧
    Insert_constraint_keyframe: bpy.props.BoolProperty(
        default=False,
        description="是否插入约束影响帧"
    )
    # 禁用约束时保持变换
    Disable_keep_transform: bpy.props.BoolProperty(
        default=False,
        description="禁用约束时保持当前变换，将约束效果烘焙到骨骼姿态上"
    )
    # 手动设置影响值（覆盖每骨骼的存储值）
    Use_manual_influence: bpy.props.BoolProperty(
        default=False,
        description="启用时使用手动设置的影响值，应用于所有选中骨骼"
    )


class MMR_Physics_property(bpy.types.PropertyGroup):

    # 碰撞组掩码属性 - 16个布尔值
    collision_group_mask: bpy.props.BoolVectorProperty(
        name="Collision Group Mask",
        size=16,  # 16个碰撞组
        default=(False,) * 16,  # 默认勾选
        description="Which collision groups this object should interact with"
    )
    # 碰撞组编号
    collision_group_index: bpy.props.IntProperty(
        name="Collision Group Index",
        default=-1,
        min=-1,
        max=15,
    )
    # 阻尼
    damping: bpy.props.FloatProperty(
        name="Damping",
        default=0.99,
        min=0.0,
        max=1.0,
    )
    # 骨骼
    bone: bpy.props.StringProperty(
        name="",
        default="",
        description="骨骼名称"
    )
    # 面板布尔值
    panel_bool: bpy.props.BoolProperty(
        default=False,
    )
    # 刚体类型(1.骨骼,2.物理,3.物理+骨骼)
    rigidbody_type: bpy.props.EnumProperty(
        name="Rigidbody Type",
        items=[
            ("0", "骨骼", "骨骼"),
            ("1", "物理", "物理"),
            ("2", "物理+骨骼", "物理+骨骼"),
        ],
        default="1",
    )

    mmr_type: bpy.props.StringProperty(
        name="MMR Type",
        default="",
    )

class MMR_Scene_Property(bpy.types.PropertyGroup):
    mmd_rigid_panel_bool: bpy.props.BoolProperty(
        default=False,
    )
    mmr_rigid_panel_bool: bpy.props.BoolProperty(
        default=False,
    )

class MMR_key_property(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(
        name="",
        default="",
        description="键名"
    )
    zh_name: bpy.props.StringProperty(
        name="",
        default="",
        description="中文键名"
    )
    value: bpy.props.FloatProperty(
        name="",
        default=0.0,
        min=0.0,
        max=1.0,
        description="键值"
    )
    select: bpy.props.BoolProperty(
        default=False,
    )
    bool_value: bpy.props.BoolProperty(
        default=True,
    )
    meshkey_index: bpy.props.IntProperty(
        name="Mesh Key Index",
        default=-1,
    )
    # 指针
    meshkey: bpy.props.PointerProperty(
        name="Mesh Key",
        type=bpy.types.Key,
    )
